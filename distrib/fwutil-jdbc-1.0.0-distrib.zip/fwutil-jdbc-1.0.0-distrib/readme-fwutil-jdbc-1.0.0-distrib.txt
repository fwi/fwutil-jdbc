This package contains the compiled (Java 7) code from fwutil-jdbc (https://github.com/fwi/fwutil-jdbc).
The Maven deploy-script needs to be modified before it can be used to deploy the artifacts 
(the first Maven install command should work fine without modification).
Search for "-Durl" and point it to the Maven (shared) repository.
If credentials are required to deploy, use the "repositoryId" option.
See for more info https://maven.apache.org/plugins/maven-deploy-plugin/deploy-file-mojo.html